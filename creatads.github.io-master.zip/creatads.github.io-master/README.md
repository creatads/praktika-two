## Олег Федотов

[Урок 2](https://github.com/creatads/lesson-2 "https://github.com/creatads/lesson-2") Работа с графикой

[Урок 3](https://github.com/creatads/lesson-3 "https://github.com/creatads/lesson-3") Настройка рабочего пространства

[Урок 4 и 5](https://github.com/creatads/lesson-4 "https://github.com/creatads/lesson-4") Знакомство с основами HTML и CSS  

[Урок 6](https://github.com/creatads/lesson-6 "https://github.com/creatads/lesson-6") Позиционирование в CSS 

[Урок 7](https://github.com/creatads/lesson-7 "https://github.com/creatads/lesson-7") Верстка первого макета

[Урок 8](https://github.com/creatads/lesson-8 "https://github.com/creatads/lesson-8") Ускорение верстки

[Урок 9](https://github.com/creatads/lesson-9 "https://github.com/creatads/lesson-9") Верстка при помощи Bootstrap 4

[Урок 10 ](https://github.com/creatads/lesson-10 "https://github.com/creatads/lesson-10") LESS

[Урок 11 ](https://github.com/creatads/lesson-11 "https://github.com/creatads/lesson-11") Сниппеты 

[Урок 13 ](https://github.com/creatads/lesson-13 "https://github.com/creatads/lesson-13") Адаптивная верстка 

[Практика header ](https://github.com/creatads/praktika-header "https://github.com/creatads/praktika-header") Практика header 

[Урок 14 ](https://github.com/creatads/lesson-14 "https://github.com/creatads/lesson-14") Подключение шрифтов

[Практика two ](https://github.com/creatads/praktika-two "https://github.com/creatads/praktika-two") Подключение шрифтов. Верстка первого экрана.


